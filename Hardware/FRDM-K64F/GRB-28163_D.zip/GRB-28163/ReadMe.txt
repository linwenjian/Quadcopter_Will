README for GRB-28163_D.zip

Company Part Number: 170-28163 REV D

Date : Thu, 27 Feb 2014 23:34:44 GMT

Freescale Semiconductor
Periferico Sur # 8110
Jalisco, Meixco CP 45609

Company Contact: Alberto Carrillo
Work Phone: (52)333-2832100 x 3059
Email: albertocarrillo@freescale.com