README for GRB-27167_C.zip

Company Part Number: 170-27167 REV C

Date : 11/18/2011 04:30:10

Freescale Semiconductor
7700 West Parmer Lane
Austin, TX 78729
Maildrop: PL59

Company Contact: Tong Emily
	Work Phone: (512)996-5167
		 Email:	 rat279@freescale.com