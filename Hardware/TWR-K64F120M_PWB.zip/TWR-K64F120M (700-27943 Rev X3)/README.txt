               Hardware Reference Design -- Read Me Document
--------------------------------------------------------------------------------

Refer to the licence agreement for information on your rights to use the files
in this package. 

The files included in this reference design package are identified as follows:

AAA-XXXXXXX_Y

Where AAA is the document identifier, XXXXX is the numerical identifier for 
this specific hardware design, and Y is the revision letter.

Document Identifiers:
LAY - Layout source (Allegro)
NET - Netlist (OrCad/Allegro)
GRB - Gerber files
ODB - ODB++ files
FAB - Fabrication document
UNI - UniCAM file
CEN - placement file
BOM - Bill of Materials
SCH - Schematic source (OrCad)
SPF - Schematic PDF

