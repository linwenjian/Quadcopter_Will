README for GRB-27943_B.zip

Company Part Number: 170-27943 REV B

Date : Tue, 24 Sep 2013 13:56:55 GMT

Freescale
Periferico Sur 8110
Colonia el Mante
45609
Tlaquepaque Jal, México

Company Contact: Mario Velasco
	Work Phone: +52 (33) 32832208
		 Email: mario.velascogonzalez@freescale.com